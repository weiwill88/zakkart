const { getCollection } = require('../config/database')

const USERS_COLLECTION = 'users'
const SUPPLIER_PERMISSION_ALIAS_MAP = {
  view_contract_detail: ['view_contract_detail', 'contract_view'],
  view_contract_amount: ['view_contract_amount', 'contract_amount'],
  mark_produced: ['mark_produced'],
  create_shipment: ['create_shipment', 'shipping_create'],
  view_shipment: ['view_shipment', 'shipping_photo', 'shipment_confirm'],
  confirm_receiving: ['confirm_receiving', 'receive_confirm'],
  manage_members: ['manage_members']
}

function isAdminRole(role) {
  return ['super_admin', 'admin', 'merchandiser'].includes(role)
}

function isSupplierRole(role) {
  return ['supplier_owner', 'supplier_member'].includes(role)
}

function ensureAdmin(auth, message = '无权限执行该操作') {
  if (!auth || !isAdminRole(auth.role)) {
    const error = new Error(message)
    error.code = 403
    throw error
  }
}

function ensureSupplierOrAdmin(auth, message = '无权限执行该操作') {
  if (!auth || (!isAdminRole(auth.role) && !isSupplierRole(auth.role))) {
    const error = new Error(message)
    error.code = 403
    throw error
  }
}

async function ensureSupplierPermission(auth, permissionKeys = [], message = '当前账号没有对应权限') {
  const hasPermission = await hasSupplierPermission(auth, permissionKeys)
  if (hasPermission) {
    return
  }

  const error = new Error(message)
  error.code = 403
  throw error
}

async function hasSupplierPermission(auth, permissionKeys = []) {
  if (!auth) {
    return false
  }

  if (isAdminRole(auth.role) || auth.role === 'supplier_owner') {
    return true
  }

  if (auth.role !== 'supplier_member') {
    return false
  }

  const userResult = await getCollection(USERS_COLLECTION).doc(auth.user_id).get().catch(() => ({ data: null }))
  const permissions = userResult.data?.permissions || []
  const grantedKeys = new Set(
    permissions
      .filter((item) => {
        if (!item) {
          return false
        }
        if (typeof item === 'string') {
          return true
        }
        return item.granted !== false
      })
      .map((item) => (typeof item === 'string' ? item : item.permission_key))
      .filter(Boolean)
  )

  const candidateKeys = expandPermissionKeys(permissionKeys)
  if (candidateKeys.some((key) => grantedKeys.has(key))) {
    return true
  }
  return false
}

function expandPermissionKeys(permissionKeys = []) {
  return Array.from(new Set(
    (Array.isArray(permissionKeys) ? permissionKeys : [permissionKeys])
      .filter(Boolean)
      .flatMap((key) => SUPPLIER_PERMISSION_ALIAS_MAP[key] || [key])
  ))
}

function ensureOrgAccess(auth, orgId, message = '无权访问该组织数据') {
  if (!auth) {
    const error = new Error(message)
    error.code = 403
    throw error
  }

  if (isAdminRole(auth.role)) {
    return
  }

  if (!orgId || auth.org_id !== orgId) {
    const error = new Error(message)
    error.code = 403
    throw error
  }
}

module.exports = {
  isAdminRole,
  isSupplierRole,
  ensureAdmin,
  ensureSupplierOrAdmin,
  hasSupplierPermission,
  ensureSupplierPermission,
  ensureOrgAccess
}
